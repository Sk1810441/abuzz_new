export const environment = {
  production: true,
  baseUrl: "https://liveapi-booking.liveabuzz.com/abuzz-booking/",
  baseUrlpayment:"https://api1.liveabuzz.com/",
  source : 6,
  key: "U2FsdGVkX18ZUVvShFSES21qHsQEqZXMxQ9zgHy+bu0=",
  salt: "54IzSRi",
  countrycode:'91',
};
