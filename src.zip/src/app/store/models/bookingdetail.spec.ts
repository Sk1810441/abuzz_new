import { Bookingdetail } from './bookingdetail';

describe('Bookingdetail', () => {
  it('should create an instance', () => {
    expect(new Bookingdetail()).toBeTruthy();
  });
});
