import { statusDescription } from './statusDescription';

export class userprofile {
    statusDescription:statusDescription | undefined;
    profileDetails: profileDetails | undefined;
}

export class profileDetails {
    "id": number | undefined;
    "msisdn": string | undefined;
    "email": string | undefined;
    "countryCode": string | undefined;
    "accountStatus": string | undefined;
    "registerDate": string | undefined;
    "notificationFlag": string | undefined;
    "fcmToken": string | undefined;
    "lastSeenDateTime": string | undefined;
    "loginStatus": string | undefined;
    "appVersion": string | undefined;
    "appOs": string | undefined;
    "appChannel": string | undefined;
    "deviceName": string | undefined;
    "name": string | undefined;
    "lastname": string | undefined;
    "source": string | undefined;
    "gender": string | undefined;
    "emailStatus": string | undefined;
    "dob": string | undefined;
    "profileImageHttp": string|undefined;
    "profileSatus": string | undefined;

}
