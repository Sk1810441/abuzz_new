import { userprofile } from './userprofile';

describe('UserDetails', () => {
  it('should create an instance', () => {
    expect(new userprofile()).toBeTruthy();
  });
});
