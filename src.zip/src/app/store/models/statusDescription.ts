export class statusDescription {
    statusCode : number | undefined;
    statusMessage : string | undefined;
    transactionId: string | undefined;
}
