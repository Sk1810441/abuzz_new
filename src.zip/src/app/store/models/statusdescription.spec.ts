import { statusDescription } from './statusDescription';

describe('StatusDescription', () => {
  it('should create an instance', () => {
    expect(new statusDescription()).toBeTruthy();
  });
});
