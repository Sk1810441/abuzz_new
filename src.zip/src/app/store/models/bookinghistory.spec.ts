import { Bookinghistory } from './bookinghistory';

describe('Bookinghistory', () => {
  it('should create an instance', () => {
    expect(new Bookinghistory()).toBeTruthy();
  });
});
