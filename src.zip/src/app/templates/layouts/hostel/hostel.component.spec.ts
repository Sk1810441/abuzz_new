import { ComponentFixture, TestBed } from '@angular/core/testing';

import { hostelComponent } from './hostel.component';

describe('hostelComponent', () => {
  let component: hostelComponent;
  let fixture: ComponentFixture<hostelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ hostelComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(hostelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
