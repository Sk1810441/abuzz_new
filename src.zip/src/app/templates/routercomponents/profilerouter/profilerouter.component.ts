import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profilerouter',
  templateUrl: './profilerouter.component.html',
  styleUrls: ['./profilerouter.component.css']
})
export class ProfilerouterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
