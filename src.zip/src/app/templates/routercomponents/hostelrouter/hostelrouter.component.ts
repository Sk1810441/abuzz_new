import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hostelrouter',
  templateUrl: './hostelrouter.component.html',
  styleUrls: ['./hostelrouter.component.css']
})
export class HostelrouterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
