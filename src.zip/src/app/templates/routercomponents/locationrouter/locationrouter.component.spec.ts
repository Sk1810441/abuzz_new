import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LocationrouterComponent } from './locationrouter.component';

describe('LocationrouterComponent', () => {
  let component: LocationrouterComponent;
  let fixture: ComponentFixture<LocationrouterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LocationrouterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LocationrouterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
