import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookinghistoryrouter',
  templateUrl: './bookinghistoryrouter.component.html',
  styleUrls: ['./bookinghistoryrouter.component.css']
})
export class BookinghistoryrouterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
