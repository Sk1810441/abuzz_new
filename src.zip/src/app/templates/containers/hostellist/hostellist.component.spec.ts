import { ComponentFixture, TestBed } from '@angular/core/testing';

import { hostellistComponent } from './hostellist.component';

describe('hostellistComponent', () => {
  let component: hostellistComponent;
  let fixture: ComponentFixture<hostellistComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ hostellistComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(hostellistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
