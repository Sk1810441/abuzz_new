import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookinglist',
  templateUrl: './bookinglist.component.html',
  styleUrls: ['./bookinglist.component.css']
})
export class BookinglistComponent implements OnInit {
  @Input() bookingDetails: any | undefined;
  constructor() { }

  ngOnInit(): void {
    // console.log(this.bookingDetails);
  }

}
