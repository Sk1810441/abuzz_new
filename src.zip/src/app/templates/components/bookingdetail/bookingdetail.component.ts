import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: '[app-bookingdetail]',
  templateUrl: './bookingdetail.component.html',
  styleUrls: ['./bookingdetail.component.css']
})
export class BookingdetailComponent implements OnInit {

  
  constructor() { }

  ngOnInit(): void {
  }

}
