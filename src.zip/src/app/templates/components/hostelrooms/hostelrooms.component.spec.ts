import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HostelroomsComponent } from './hostelrooms.component';

describe('HostelroomsComponent', () => {
  let component: HostelroomsComponent;
  let fixture: ComponentFixture<HostelroomsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HostelroomsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HostelroomsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
