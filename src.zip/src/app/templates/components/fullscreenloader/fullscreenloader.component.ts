import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-fullscreenloader',
  templateUrl: './fullscreenloader.component.html',
  styleUrls: ['./fullscreenloader.component.css']
})
export class FullscreenloaderComponent implements OnInit {

  @Input() isLoading:boolean | undefined;
  constructor() { }

  ngOnInit(): void {}

}
