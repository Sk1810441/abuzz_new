import { ComponentFixture, TestBed } from '@angular/core/testing';

import { hostelcardComponent } from './hostelcard.component';

describe('hostelcardComponent', () => {
  let component: hostelcardComponent;
  let fixture: ComponentFixture<hostelcardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ hostelcardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(hostelcardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
