import { Component } from '@angular/core';
//import { JpPreloadService } from '@jaspero/ng-image-preload';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  {

  constructor(
    //private preload: JpPreloadService 
    ) { }
  title = 'oxfordcaps';

  
  // ngOnInit(): void {
  //   //this.preload.initialize();
  // }


}
